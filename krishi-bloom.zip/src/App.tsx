import { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './views/Home';
import About from './views/About';
import Education from './views/Education';
import Schemes from './views/Schemes';
import Advisory from './views/Advisory';
import Contact from './views/Contact';
import { ViewState } from './types';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('home');

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <Home setCurrentView={setCurrentView} />;
      case 'about':
        return <About />;
      case 'education':
        return <Education />;
      case 'schemes':
        return <Schemes />;
      case 'advisory':
        return <Advisory />;
      case 'contact':
        return <Contact />;
      default:
        return <Home setCurrentView={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-900 bg-white">
      <Header currentView={currentView} setCurrentView={setCurrentView} />
      
      <main className="flex-grow">
        {renderView()}
      </main>
      
      <Footer />
    </div>
  );
}
