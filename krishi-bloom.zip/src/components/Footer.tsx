import { Leaf } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 py-12 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="bg-green-600 text-white p-2 rounded-xl">
              <Leaf className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white tracking-tight">Krishi Bloom</h2>
              <p className="text-sm text-green-400 font-medium">ज्ञान से खेती, विकास से समृद्धि</p>
            </div>
          </div>
          
          <div className="flex gap-6 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Help Center</a>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-500">
          <p>© 2026 Krishi Bloom. All rights reserved.</p>
          <p className="mt-2">Empowering Indian Farmers & Agriculture Students.</p>
        </div>
      </div>
    </footer>
  );
}
