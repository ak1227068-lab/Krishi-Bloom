export type ViewState = 'home' | 'about' | 'education' | 'schemes' | 'advisory' | 'contact';

export interface Scheme {
  id: string;
  name: string;
  eligibility: string;
  benefits: string;
  documents: string;
  application: string;
  link: string;
}

export interface Review {
  id: string;
  name: string;
  role: string;
  content: string;
  avatar?: string;
}
