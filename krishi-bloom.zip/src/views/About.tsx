import { Leaf, Users, Globe2, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  return (
    <div className="py-16 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600 mb-6">
            <Leaf className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-extrabold text-gray-900 mb-6">About Krishi Bloom</h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Krishi Bloom is a comprehensive digital agriculture platform dedicated to empowering Indian farmers and agriculture students. 
            Our mission is encapsulated in our tagline: <span className="font-semibold text-green-700">"ज्ञान से खेती, विकास से समृद्धि"</span> (Farming with Knowledge, Prosperity through Progress).
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-20">
          <div className="bg-gray-50 rounded-2xl p-8 text-center ring-1 ring-gray-100">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Globe2 className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-xl text-gray-900 mb-2">Digital Accessibility</h3>
            <p className="text-gray-600">Bringing critical government scheme information and advisory directly to the farmer's smartphone.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-8 text-center ring-1 ring-gray-100">
            <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-xl text-gray-900 mb-2">Quality Education</h3>
            <p className="text-gray-600">Providing structured, affordable, and high-quality study materials for agriculture students across India.</p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-8 text-center ring-1 ring-gray-100">
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-xl text-gray-900 mb-2">Community Driven</h3>
            <p className="text-gray-600">Founded in 2026, we aim to build a community where knowledge sharing leads to collective prosperity.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
