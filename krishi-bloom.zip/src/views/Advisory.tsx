import { Sprout, Droplets, Bug, CloudSun, Beaker, ShieldCheck, Sun, Tractor } from 'lucide-react';

const ADVISORIES = [
  {
    title: "Crop Management",
    icon: Sprout,
    color: "bg-green-100 text-green-700",
    description: "Best practices for sowing, crop rotation, and harvesting various seasonal crops. Monitor crop health stages closely to maximize yield potential."
  },
  {
    title: "Soil Management",
    icon: Tractor,
    color: "bg-amber-100 text-amber-800",
    description: "Guidelines on soil testing, maintaining pH levels, preventing erosion, and enhancing organic carbon content for sustainable farming."
  },
  {
    title: "Irrigation",
    icon: Droplets,
    color: "bg-blue-100 text-blue-700",
    description: "Efficient water management techniques including drip and sprinkler irrigation schedules tailored for specific crop water requirements."
  },
  {
    title: "Fertilizer Management",
    icon: Beaker,
    color: "bg-purple-100 text-purple-700",
    description: "Optimal NPK ratios, micro-nutrient applications, and transitioning strategies for integrated nutrient management to reduce soil degradation."
  },
  {
    title: "Pest & Disease Management",
    icon: Bug,
    color: "bg-red-100 text-red-700",
    description: "Early identification and integrated pest management (IPM) strategies to control outbreaks using biological and safe chemical controls."
  },
  {
    title: "Seed Selection",
    icon: Sun,
    color: "bg-orange-100 text-orange-700",
    description: "Choosing certified, high-yielding, and climate-resilient seed varieties suitable for your specific agro-climatic zone."
  },
  {
    title: "Organic/Natural Farming",
    icon: ShieldCheck,
    color: "bg-emerald-100 text-emerald-700",
    description: "Methods for preparing Jeevamrutha, vermicompost, and utilizing botanical extracts for chemical-free, sustainable agriculture."
  },
  {
    title: "Weather-based Advisory",
    icon: CloudSun,
    color: "bg-cyan-100 text-cyan-700",
    description: "Real-time adjustments to farming operations based on rainfall forecasts, temperature fluctuations, and extreme weather alerts."
  }
];

export default function Advisory() {
  return (
    <div className="py-12 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Agricultural Advisory</h1>
          <p className="text-xl text-gray-600">
            Practical, expert-backed information to help you manage your farm efficiently and sustainably across every stage of the crop cycle.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {ADVISORIES.map((advisory, i) => {
            const Icon = advisory.icon;
            return (
              <div key={i} className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:border-green-300 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 ${advisory.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-3">{advisory.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {advisory.description}
                </p>
                <button className="mt-4 text-sm font-bold text-green-700 hover:text-green-800 transition-colors">
                  Read Guide &rarr;
                </button>
              </div>
            );
          })}
        </div>

        <div className="mt-16 bg-green-50 rounded-3xl p-8 md:p-12 border border-green-100 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Need personalized advice?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Upload images of your crop issues or soil reports, and our experts will provide customized recommendations to resolve your farming challenges.
          </p>
          <button className="bg-green-600 text-white px-8 py-3 rounded-xl font-bold shadow-md hover:bg-green-700 transition-colors">
            Ask an Expert
          </button>
        </div>

      </div>
    </div>
  );
}
