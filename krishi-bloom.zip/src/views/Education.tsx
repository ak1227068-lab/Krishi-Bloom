import { BookOpen, FileText, Video, Image as ImageIcon, FileQuestion, GraduationCap } from 'lucide-react';
import { motion } from 'motion/react';

const SUBJECTS = [
  "Agronomy", "Soil Science", "Horticulture", "Entomology", 
  "Plant Pathology", "Genetics & Plant Breeding", 
  "Agricultural Economics", "Agricultural Extension"
];

const RESOURCE_TYPES = [
  { label: "PDF Notes", icon: FileText, color: "bg-blue-50 text-blue-600" },
  { label: "Educational Videos", icon: Video, color: "bg-red-50 text-red-600" },
  { label: "Agriculture Images", icon: ImageIcon, color: "bg-emerald-50 text-emerald-600" },
  { label: "MCQs & Quizzes", icon: FileQuestion, color: "bg-amber-50 text-amber-600" },
  { label: "Previous-Year Qs", icon: BookOpen, color: "bg-purple-50 text-purple-600" },
];

export default function Education() {
  return (
    <div className="py-12 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-100 text-amber-600 mb-6">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Agriculture Education</h1>
          <p className="text-xl text-gray-600">
            Comprehensive learning resources for students, researchers, and progressive farmers.
          </p>
        </div>

        {/* Resource Types Grid */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Study Materials</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {RESOURCE_TYPES.map((type, i) => {
              const Icon = type.icon;
              return (
                <motion.button 
                  whileHover={{ y: -2 }}
                  key={i} 
                  className="flex flex-col items-center p-6 bg-white rounded-2xl shadow-sm ring-1 ring-gray-200 hover:shadow-md transition-all group"
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-4 ${type.color} group-hover:scale-110 transition-transform`}>
                    <Icon className="w-7 h-7" />
                  </div>
                  <span className="font-semibold text-gray-900 text-center">{type.label}</span>
                </motion.button>
              )
            })}
          </div>
        </div>

        {/* Subject-wise Content */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Subject-wise Content</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {SUBJECTS.map((subject, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm ring-1 ring-gray-200 hover:ring-green-500 transition-colors group cursor-pointer border-l-4 border-l-transparent hover:border-l-green-500">
                <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-green-700 transition-colors">{subject}</h3>
                <p className="text-sm text-gray-500 mb-4">Modules, notes, and question banks covering core concepts of {subject.toLowerCase()}.</p>
                <span className="text-sm font-medium text-green-600 flex items-center gap-1 group-hover:gap-2 transition-all">
                  Browse topics &rarr;
                </span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
