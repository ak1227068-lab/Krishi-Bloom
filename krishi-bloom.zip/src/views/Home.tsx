import { motion } from 'motion/react';
import { Sprout, BookOpen, Landmark, ArrowRight, Star, CheckCircle2 } from 'lucide-react';
import { ViewState } from '../types';

interface HomeProps {
  setCurrentView: (view: ViewState) => void;
}

export default function Home({ setCurrentView }: HomeProps) {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-50 to-emerald-100/50 pt-16 pb-24 lg:pt-24 lg:pb-32">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-100 text-green-800 font-medium text-sm mb-6 shadow-sm ring-1 ring-green-600/10"
            >
              <Sprout className="w-4 h-4" />
              <span>Founded in 2026 for India's Future</span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight mb-6"
            >
              Grow with <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-emerald-600">Krishi Bloom</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl text-gray-600 mb-10 leading-relaxed"
            >
              Your trusted digital agriculture platform. Providing vital information, government schemes, expert advisory, and comprehensive educational resources for farmers and agriculture students across India.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row justify-center gap-4"
            >
              <button 
                onClick={() => setCurrentView('advisory')}
                className="px-8 py-3.5 rounded-full bg-green-600 text-white font-medium shadow-lg shadow-green-600/30 hover:bg-green-700 transition-all hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2"
              >
                Get Advisory <ArrowRight className="w-4 h-4" />
              </button>
              <button 
                onClick={() => setCurrentView('education')}
                className="px-8 py-3.5 rounded-full bg-white text-gray-900 font-medium shadow-md shadow-gray-200/50 hover:bg-gray-50 transition-all ring-1 ring-gray-200 flex items-center justify-center gap-2"
              >
                Explore Study Material <BookOpen className="w-4 h-4 text-green-600" />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 3 Clickable Cards Section */}
      <section className="py-16 bg-white relative -mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            <motion.div 
              whileHover={{ y: -5 }}
              onClick={() => setCurrentView('schemes')}
              className="bg-white rounded-2xl p-8 shadow-xl shadow-green-900/5 ring-1 ring-gray-100 cursor-pointer group"
            >
              <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-6 group-hover:scale-110 transition-transform">
                <Landmark className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Government Schemes</h3>
              <p className="text-gray-600 mb-4">Discover eligibility, benefits, and how to apply for central and state farming schemes.</p>
              <span className="text-blue-600 font-medium flex items-center gap-1 group-hover:gap-2 transition-all">Explore Schemes <ArrowRight className="w-4 h-4" /></span>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              onClick={() => setCurrentView('advisory')}
              className="bg-white rounded-2xl p-8 shadow-xl shadow-green-900/5 ring-1 ring-gray-100 cursor-pointer group"
            >
              <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-600 mb-6 group-hover:scale-110 transition-transform">
                <Sprout className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Expert Advisory</h3>
              <p className="text-gray-600 mb-4">Practical guidance on crop management, soil health, irrigation, and pest control.</p>
              <span className="text-green-600 font-medium flex items-center gap-1 group-hover:gap-2 transition-all">Get Advice <ArrowRight className="w-4 h-4" /></span>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              onClick={() => setCurrentView('education')}
              className="bg-white rounded-2xl p-8 shadow-xl shadow-green-900/5 ring-1 ring-gray-100 cursor-pointer group"
            >
              <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-600 mb-6 group-hover:scale-110 transition-transform">
                <BookOpen className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Agriculture Education</h3>
              <p className="text-gray-600 mb-4">Comprehensive notes, MCQs, and videos for B.Sc Ag and competitive exams.</p>
              <span className="text-amber-600 font-medium flex items-center gap-1 group-hover:gap-2 transition-all">Start Learning <ArrowRight className="w-4 h-4" /></span>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Articles & Study Materials */}
      <section className="py-16 bg-gray-50 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Latest Insights & Materials</h2>
              <p className="text-gray-600 max-w-2xl">Stay updated with modern farming techniques and top-tier study resources.</p>
            </div>
            <button 
              onClick={() => setCurrentView('education')}
              className="text-green-600 font-medium flex items-center gap-1 hover:text-green-700"
            >
              View all resources <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "Organic Farming Best Practices 2026", type: "Article", color: "text-emerald-700 bg-emerald-50" },
              { title: "Agronomy Sem 4 Complete PDF Notes", type: "Study Material", color: "text-amber-700 bg-amber-50" },
              { title: "Weather-based Crop Advisory for Kharif", type: "Advisory", color: "text-blue-700 bg-blue-50" },
              { title: "Top 50 MCQs on Soil Science", type: "Quiz", color: "text-purple-700 bg-purple-50" }
            ].map((item, i) => (
              <div key={i} className="bg-white rounded-xl p-5 shadow-sm ring-1 ring-gray-100 hover:shadow-md transition-shadow cursor-pointer">
                <span className={`inline-block px-2.5 py-1 rounded-md text-xs font-semibold mb-4 ${item.color}`}>
                  {item.type}
                </span>
                <h4 className="font-bold text-gray-900 mb-2 leading-snug">{item.title}</h4>
                <p className="text-sm text-gray-500 line-clamp-2">A comprehensive guide and resource material updated for the current academic and agricultural year.</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
            <p className="text-gray-600">Choose the plan that fits your needs. Empowering everyone from local farmers to advanced students.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Free Tier */}
            <div className="rounded-3xl p-8 bg-white shadow-xl shadow-gray-200/50 ring-1 ring-gray-200">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Free</h3>
              <p className="text-gray-500 mb-6">For basic knowledge</p>
              <div className="mb-6">
                <span className="text-4xl font-extrabold text-gray-900">₹0</span>
                <span className="text-gray-500">/forever</span>
              </div>
              <ul className="space-y-4 mb-8">
                {['Basic agricultural articles', 'Government schemes directory', 'General advisory alerts'].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <button className="w-full py-3 px-4 rounded-xl font-medium text-green-700 bg-green-50 hover:bg-green-100 transition-colors">
                Start for Free
              </button>
            </div>

            {/* Student Tier */}
            <div className="rounded-3xl p-8 bg-green-600 text-white shadow-2xl shadow-green-600/40 ring-1 ring-green-600 relative transform md:-translate-y-4">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-amber-400 to-amber-500 text-amber-950 px-4 py-1 rounded-full text-sm font-bold shadow-sm">
                Most Popular
              </div>
              <h3 className="text-2xl font-bold mb-2">Student</h3>
              <p className="text-green-100 mb-6">Perfect for exam prep</p>
              <div className="mb-6">
                <span className="text-4xl font-extrabold">₹99</span>
                <span className="text-green-200">/month</span>
              </div>
              <ul className="space-y-4 mb-8">
                {['Everything in Free', 'Complete PDF Notes', 'Subject-wise MCQs & Quizzes', 'Previous-Year Questions'].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-green-50">
                    <CheckCircle2 className="w-5 h-5 text-green-300 shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <button className="w-full py-3 px-4 rounded-xl font-bold text-green-700 bg-white hover:bg-gray-50 transition-colors shadow-sm">
                Subscribe Now
              </button>
            </div>

            {/* Pro Tier */}
            <div className="rounded-3xl p-8 bg-white shadow-xl shadow-gray-200/50 ring-1 ring-gray-200">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Pro</h3>
              <p className="text-gray-500 mb-6">For complete mastery</p>
              <div className="mb-6">
                <span className="text-4xl font-extrabold text-gray-900">₹199</span>
                <span className="text-gray-500">/month</span>
              </div>
              <ul className="space-y-4 mb-8">
                {['Everything in Student', 'Full Study Material', 'Exclusive Educational Videos', 'High-res Agriculture Images', 'Priority Expert Support'].map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <button className="w-full py-3 px-4 rounded-xl font-medium text-green-700 bg-green-50 hover:bg-green-100 transition-colors">
                Get Pro Access
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-emerald-50/50 border-t border-emerald-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Trusted by Thousands</h2>
            <p className="text-gray-600">Hear from farmers and students using Krishi Bloom.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { name: "Rajesh Kumar", role: "Farmer, Punjab", text: "The advisory section helped me understand the right time to use fertilizers for my wheat crop. Yield has improved significantly." },
              { name: "Priya Sharma", role: "B.Sc Agriculture Student", text: "The ₹99 student plan is a lifesaver. The PDF notes and PYQs are exactly what I needed for my semester exams." },
              { name: "Amit Patel", role: "Organic Farmer, Gujarat", text: "Found all the details for government subsidies on organic farming in one place. Very clean and easy to use website." }
            ].map((review, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl shadow-sm ring-1 ring-gray-100">
                <div className="flex text-amber-400 mb-4">
                  {[...Array(5)].map((_, j) => <Star key={j} className="w-5 h-5 fill-current" />)}
                </div>
                <p className="text-gray-700 mb-6 italic">"{review.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-700 font-bold text-lg">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">{review.name}</h4>
                    <p className="text-sm text-gray-500">{review.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
