import { Landmark, FileCheck, CheckCircle, ArrowUpRight } from 'lucide-react';

const SCHEMES = [
  {
    name: "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)",
    eligibility: "All landholding eligible farmer families (subject to exclusion criteria).",
    benefits: "Income support of ₹6,000 per year in three equal installments.",
    documents: "Aadhaar Card, Bank Account Details, Land Ownership Records.",
    application: "Online via PM-KISAN portal or through Common Service Centres (CSCs).",
    link: "https://pmkisan.gov.in/"
  },
  {
    name: "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
    eligibility: "Farmers growing notified crops in notified areas, including sharecroppers and tenant farmers.",
    benefits: "Comprehensive insurance cover against failure of crops, helping stabilize income.",
    documents: "Land Records, Aadhaar Card, Bank Passbook, Sowing Certificate.",
    application: "Through banks, CSCs, or the national crop insurance portal.",
    link: "https://pmfby.gov.in/"
  },
  {
    name: "Kisan Credit Card (KCC)",
    eligibility: "All farmers, tenant farmers, oral lessees, and sharecroppers.",
    benefits: "Adequate and timely credit support under a single window for cultivation and other needs.",
    documents: "ID Proof, Address Proof, Land Documents.",
    application: "Apply at any commercial bank, regional rural bank, or cooperative bank.",
    link: "https://sbi.co.in/web/agri-rural/agriculture-banking/crop-loan/kisan-credit-card"
  },
  {
    name: "Paramparagat Krishi Vikas Yojana (PKVY)",
    eligibility: "Farmers willing to form clusters and adopt organic farming.",
    benefits: "Financial assistance of ₹50,000 per hectare for three years for inputs, certification, and marketing.",
    documents: "Aadhaar Card, Land Details, Cluster Formation Documents.",
    application: "Through State Agriculture Departments or local agriculture officers.",
    link: "https://pgsindia-ncof.gov.in/pkvy/index.aspx"
  }
];

export default function Schemes() {
  return (
    <div className="py-12 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-100 text-blue-800 font-medium text-sm mb-4">
            <Landmark className="w-4 h-4" /> State & Central Support
          </div>
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Government Schemes</h1>
          <p className="text-xl text-gray-600">
            Explore beneficial initiatives to support your agricultural growth, secure your harvest, and improve financial stability.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {SCHEMES.map((scheme, i) => (
            <div key={i} className="bg-white rounded-2xl shadow-sm ring-1 ring-gray-200 overflow-hidden flex flex-col h-full">
              <div className="p-6 md:p-8 flex-grow">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">{scheme.name}</h2>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-1 text-blue-700">Benefits</h3>
                    <p className="text-gray-700 flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                      {scheme.benefits}
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-1 mt-2 text-blue-700">Eligibility</h3>
                      <p className="text-gray-600 text-sm">{scheme.eligibility}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-1 mt-2 text-blue-700">Required Documents</h3>
                      <p className="text-gray-600 text-sm flex items-start gap-1">
                        <FileCheck className="w-4 h-4 shrink-0 text-gray-400 mt-0.5" />
                        {scheme.documents}
                      </p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-1 mt-2 text-blue-700">How to Apply</h3>
                    <p className="text-gray-600 text-sm">{scheme.application}</p>
                  </div>
                </div>
              </div>
              <div className="px-6 md:px-8 py-4 bg-gray-50 border-t border-gray-100 mt-auto">
                <a 
                  href={scheme.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-blue-700 font-medium hover:text-blue-800 transition-colors"
                >
                  Visit Official Portal <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
